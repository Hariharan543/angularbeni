package com.example.demo.VehiclePortalException;

public class VehiclePortalException extends Exception{
	public VehiclePortalException(String msg) {
		super(msg);
	}
	
	

}
