package com.example.demo.VehiclePortalBean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_vehicle")
public class VehiclePortalVehicleBean {

	@Id
	@Column(name="vin")
	private String vin;
	
	@Column(name="model_line")
	private String model_line;
	
	@Column(name="model_year")
	private int model_year;
	
	@Column(name="interior_color")
	private String interior_color;
	
	@Column(name="exterior_color")
	private String exterior_color;
	
	@Column(name="drive_train")
	private String drive_train;

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getModel_line() {
		return model_line;
	}

	public void setModel_line(String model_line) {
		this.model_line = model_line;
	}

	public int getModel_year() {
		return model_year;
	}

	public void setModel_year(int model_year) {
		this.model_year = model_year;
	}

	public String getInterior_color() {
		return interior_color;
	}

	public void setInterior_color(String interior_color) {
		this.interior_color = interior_color;
	}

	public String getExterior_color() {
		return exterior_color;
	}

	public void setExterior_color(String exterior_color) {
		this.exterior_color = exterior_color;
	}

	public String getDrive_train() {
		return drive_train;
	}

	public void setDrive_train(String drive_train) {
		this.drive_train = drive_train;
	}

	public VehiclePortalVehicleBean(String vin, String model_line, int model_year, String interior_color,
			String exterior_color, String drive_train) {
	
		this.vin = vin;
		this.model_line = model_line;
		this.model_year = model_year;
		this.interior_color = interior_color;
		this.exterior_color = exterior_color;
		this.drive_train = drive_train;
	}

	public VehiclePortalVehicleBean() {
		
	}
	
	

}