package com.example.demo.VehiclePortalService;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.VehiclePortalBean.VehiclePortalUserBean;
import com.example.demo.VehiclePortalBean.VehiclePortalVehicleBean;
import com.example.demo.VehiclePortalException.VehiclePortalException;
import com.example.demo.VehiclePortalRepository.VehiclePortalRepositoryImpl;

@Service
@Transactional
public class VehiclePortalServiceImpl  implements VehiclePortalService{
	
	@Autowired
	private VehiclePortalRepositoryImpl vehicleportalrepo;

	@Override
	public boolean getUser(VehiclePortalUserBean userdata) {
		// TODO Auto-generated method stub
		return vehicleportalrepo.getUser(userdata);
	}

	@Override
	public List userData() {
		// TODO Auto-generated method stub
		return vehicleportalrepo.userData();
	}

	@Override
	public boolean getVehicle(VehiclePortalVehicleBean vehicleData) {
		// TODO Auto-generated method stub
		return vehicleportalrepo.getVehicle(vehicleData);
	}

	@Override
	public List vehicleData() {
		// TODO Auto-generated method stub
		return vehicleportalrepo.vehicleData();
	}

	

	public List searchVehicle(String model_line) {
		// TODO Auto-generated method stub
		return vehicleportalrepo.searchVehicle(model_line);
	}

	@Override
	public boolean validateLogin(int user_id, String user_password) throws VehiclePortalException {
		// TODO Auto-generated method stub
		return vehicleportalrepo.validateLogin(user_id, user_password);
	}

	

}



