package com.example.demo.VehiclePortalRepository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.VehiclePortalBean.VehiclePortalUserBean;
import com.example.demo.VehiclePortalBean.VehiclePortalVehicleBean;
import com.example.demo.VehiclePortalException.VehiclePortalException;

@Repository

public class VehiclePortalRepositoryImpl implements VehiclePortalRepository{
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean getUser(VehiclePortalUserBean userdata) {
		// TODO Auto-generated method stub
		entityManager.persist(userdata);
		return true;
	}
	
	
	@Override
	public List userData() {
		// TODO Auto-generated method stub
		List userdata=entityManager.createQuery("FROM VehiclePortalUserBean", VehiclePortalUserBean.class ).getResultList();
		return userdata;
	}

	@Override
	public boolean getVehicle(VehiclePortalVehicleBean vehicleData) {
		// TODO Auto-generated method stub
		entityManager.persist(vehicleData);
		return true;
	}
	
	
	@Override
	public List vehicleData() {
		// TODO Auto-generated method stub
		List vehicledata=entityManager.createQuery("FROM VehiclePortalVehicleBean", VehiclePortalVehicleBean.class ).getResultList();
		return vehicledata;
	}



	@Override
	public boolean validateLogin(int user_id,String user_password) throws VehiclePortalException {
		boolean res=false;
		try {
			Query query=(Query) entityManager.createQuery("from VehiclePortalUserBean where user_id=:id and user_password=:pass");
			query.setParameter("id",user_id);
			query.setParameter("pass",user_password);
			List list=query.list();
			if(list.size()>0) 
				res=true;
		}
		catch(Exception e) {
			throw new VehiclePortalException("Invalid User");
		}
		return res;
	}


	@Override
	public List searchVehicle(String model_line) {
		Query query=(Query) entityManager.createQuery("from VehiclePortalVehicleBean where model_line=:model");
		query.setParameter("model",model_line);
        List l=query.list();
		return l;
	}


	


}


	


	

