package com.example.demo.VehiclePortalRepository;

import java.util.List;

import com.example.demo.VehiclePortalBean.VehiclePortalUserBean;
import com.example.demo.VehiclePortalBean.VehiclePortalVehicleBean;
import com.example.demo.VehiclePortalException.VehiclePortalException;


public interface VehiclePortalRepository {
	public boolean getUser(VehiclePortalUserBean userData);
	public List userData();
	
	
	public boolean getVehicle(VehiclePortalVehicleBean vehicleData);
	public List vehicleData();
	public List searchVehicle(String model_line);
	boolean validateLogin(int user_id, String user_password) throws VehiclePortalException;

	
	
	

}








