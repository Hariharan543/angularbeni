package com.example.demo.VehiclePortalController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.VehiclePortalBean.VehiclePortalUserBean;
import com.example.demo.VehiclePortalBean.VehiclePortalVehicleBean;
import com.example.demo.VehiclePortalException.VehiclePortalException;
import com.example.demo.VehiclePortalService.VehiclePortalServiceImpl;

@RestController
@RequestMapping("/vehicleportal")
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*")
public class VehiclePortalController {
	
	@Autowired
	private VehiclePortalServiceImpl vehicleportalservice;
	
	
	
	@GetMapping("/listuser")
	public List<VehiclePortalUserBean> userData()
	{
		return vehicleportalservice.userData();
	}
	
	@GetMapping("/listvehicle")
	public List<VehiclePortalVehicleBean> getVehicle()
	{
		return vehicleportalservice.vehicleData();
	}
	
	@GetMapping("/validatelogin/{user_id}/{user_password}")
	public boolean validatelogin(@PathVariable (name="user_id") int user_id, @PathVariable (name="user_password") String user_password) throws VehiclePortalException{
		return vehicleportalservice.validateLogin(user_id, user_password);
	}
		
	@GetMapping("/searchVehicle/{model_line}")
	public List searchVehicle(@PathVariable (name="model_line") String model_line) {
		return vehicleportalservice.searchVehicle(model_line);
	}
	
	
		
}


	
	
	
	
	
	
















