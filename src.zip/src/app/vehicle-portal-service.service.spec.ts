import { TestBed } from '@angular/core/testing';

import { VehiclePortalServiceService } from './vehicle-portal-service.service';

describe('VehiclePortalServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VehiclePortalServiceService = TestBed.get(VehiclePortalServiceService);
    expect(service).toBeTruthy();
  });
});
