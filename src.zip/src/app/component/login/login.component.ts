import { Component, OnInit } from '@angular/core';
import { VehiclePortalServiceService } from 'src/app/vehicle-portal-service.service';
import { User } from 'src/app/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 private user:User;
  constructor(private vehiclePortalServiceService:VehiclePortalServiceService,private router:Router) { }

  ngOnInit() {
    this.user=this.vehiclePortalServiceService.getUser();
  }
  login(user){
    this.vehiclePortalServiceService.validateLogin(user.userId,user.userPassword).subscribe((data)=>{
    console.log(data);
    this.router.navigate(['/vehicle']);

  },(error)=>{
    console.log(error); 
    alert("Invalid Credentials!! ")

  })

  
}
  }

