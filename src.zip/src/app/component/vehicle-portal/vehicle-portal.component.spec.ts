import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehiclePortalComponent } from './vehicle-portal.component';

describe('VehiclePortalComponent', () => {
  let component: VehiclePortalComponent;
  let fixture: ComponentFixture<VehiclePortalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehiclePortalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehiclePortalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
