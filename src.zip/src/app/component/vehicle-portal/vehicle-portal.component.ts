import { Component, OnInit } from '@angular/core';
import { VehiclePortalServiceService } from 'src/app/vehicle-portal-service.service';
import { Router } from '@angular/router';
import { Vehicle } from 'src/app/vehicle';

@Component({
  selector: 'app-vehicle-portal',
  templateUrl: './vehicle-portal.component.html',
  styleUrls: ['./vehicle-portal.component.css']
})
export class VehiclePortalComponent implements OnInit {
  private vehicles:Vehicle
  private vehicle=new Vehicle
  
  constructor(private vehiclePortalServiceService:VehiclePortalServiceService,private router:Router) { }
 
  ngOnInit() {
    this.vehiclePortalServiceService.getVehicleList().subscribe((vehicles)=>{
      console.log(vehicles);
      this.vehicles=vehicles;
    },(error)=>{
      console.log(error);
    })
  }

  search(modelLine){

    this.vehiclePortalServiceService.searchByModel(modelLine).subscribe((vehicles)=>{
      console.log(vehicles);
      this.vehicles=vehicles;
    },(error)=>{
      console.log(error);
    })
  }
  logout(){
    this.router.navigate(['/']);
  }

}
