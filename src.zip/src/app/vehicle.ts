export class Vehicle {
    vin:string
    modelLine:string;
    modelYear:number
    interiorColor:string
    exteriorColor:string
    driveTrain:string
}
