import { Injectable } from '@angular/core';
import { Http,Response,Headers,RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Observable'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/catch'
import 'rxjs/add/Observable/throw'

import { User } from './user';
import { Vehicle } from './vehicle';

@Injectable({
  providedIn: 'root'
})
export class VehiclePortalServiceService {

  constructor(private http:Http) { }
  private user:User;
  private vehicle:Vehicle
 private baseUrl="http://localhost:8743/vehiclePortal"
 private headers=new Headers({'Content-Type':'application/json'});
 private options=new RequestOptions({headers:this.headers})
  validateLogin(userId,userPassword){
    return this.http.post(this.baseUrl+'/validateLogin/'+this.user.userId+'/'+this.user.userPassword,this.options).map((response:Response)=>response.json()).catch(this.errorhandler)
    
  }
  getVehicleList(){
    return this.http.get(this.baseUrl+'/getVehicleList',this.options).map((response:Response)=>response.json()).catch(this.errorhandler);  
   }
   searchByModel(modelLine){
    return this.http.get(this.baseUrl+'/searchByModel/'+modelLine,this.options).map((response:Response)=>response.json()).catch(this.errorhandler);  
   }

getUser(){
  this.user=new User()
 return this.user;
}
setUser( user:User){
  this.user=user;

}
getVehicle(){
  return this.vehicle;
}
setVehicle(vehicle:Vehicle){
  this.vehicle=this.vehicle;
}
errorhandler(error:Response){
  return Observable.throw(error);

}

}
