import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import{HttpModule} from '@angular/http'
import { VehiclePortalServiceService } from './vehicle-portal-service.service';
import {FormsModule} from '@angular/forms'
import { RouterModule,Routes} from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { VehiclePortalComponent } from './component/vehicle-portal/vehicle-portal.component';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'vehicle',component:VehiclePortalComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    VehiclePortalComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
     RouterModule.forRoot(routes),


    
  ],
  providers: [VehiclePortalServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
