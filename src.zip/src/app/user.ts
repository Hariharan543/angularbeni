export class User {
    userId:number;
    userPassword:string
    userName:string
    userAddress:string
}
